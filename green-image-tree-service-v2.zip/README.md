# Green Image Tree Service V2

## To run locally:
1. Run `npm install`
2. Run `npm run dev`

Deployed easily via Vercel.
